export { default as Home } from "./Home";
export { default as GrantDetails } from "./GrantDetails";
export { default as CreateGrant } from "./CreateGrant";
export { default as Profile } from "./Profile";
export { default as Registration } from "./Registration";
export { default as LandingPage } from "./LandingPage";